// Global variables
let ws;
let currentUsername = '';
let currentUserId = '';
let isTyping = false;
let typingTimeout;
let editingMessageId = null;
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;

// DOM elements
const usernameModal = document.getElementById('usernameModal');
const usernameForm = document.getElementById('usernameForm');
const usernameInput = document.getElementById('usernameInput');
const chatContainer = document.getElementById('chatContainer');
const currentUsernameSpan = document.getElementById('currentUsername');
const onlineCountSpan = document.getElementById('onlineCount');
const userCountSpan = document.getElementById('userCount');
const usersList = document.getElementById('usersList');
const messagesContainer = document.getElementById('messagesContainer');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const typingIndicator = document.getElementById('typingIndicator');
const typingText = document.getElementById('typingText');
const connectionStatus = document.getElementById('connectionStatus');
const editModal = document.getElementById('editModal');
const editForm = document.getElementById('editForm');
const editTextarea = document.getElementById('editTextarea');
const closeEditModal = document.getElementById('closeEditModal');
const cancelEdit = document.getElementById('cancelEdit');
const themeToggle = document.getElementById('themeToggle');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Chat application loaded');
    
    // Debug: Check if all DOM elements exist
    console.log('🔍 DOM Debug:');
    console.log('- usernameModal:', !!usernameModal);
    console.log('- chatContainer:', !!chatContainer);  
    console.log('- messagesContainer:', !!messagesContainer);
    console.log('- usersList:', !!usersList);
    console.log('- userCountSpan:', !!userCountSpan);
    console.log('- onlineCountSpan:', !!onlineCountSpan);
    console.log('- messageInput:', !!messageInput);
    console.log('- sendButton:', !!sendButton);
    
    // Initialize theme
    initializeTheme();
    
    // Focus on username input
    usernameInput.focus();
    
    // Handle username form submission
    usernameForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const username = usernameInput.value.trim();
        if (username) {
            console.log('👤 Setting username:', username);
            currentUsername = username;
            currentUsernameSpan.textContent = username;
            usernameModal.style.display = 'none';
            chatContainer.style.display = 'flex';
            connectWebSocket();
        }
    });
    
    // Handle message input
    messageInput.addEventListener('input', function() {
        const message = this.value.trim();
        sendButton.disabled = !message;
        
        // Handle typing indicator
        if (message && !isTyping) {
            isTyping = true;
            sendTypingStatus(true);
        } else if (!message && isTyping) {
            isTyping = false;
            sendTypingStatus(false);
        }
        
        // Clear typing timeout
        clearTimeout(typingTimeout);
        
        // Stop typing after 3 seconds of inactivity
        if (message) {
            typingTimeout = setTimeout(() => {
                if (isTyping) {
                    isTyping = false;
                    sendTypingStatus(false);
                }
            }, 3000);
        }
    });
    
    // Handle message sending
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    sendButton.addEventListener('click', sendMessage);
    
    // Handle edit modal
    closeEditModal.addEventListener('click', closeEditModalHandler);
    cancelEdit.addEventListener('click', closeEditModalHandler);
    
    editForm.addEventListener('submit', function(e) {
        e.preventDefault();
        saveEditedMessage();
    });
    
    // Handle clicking outside modal to close
    editModal.addEventListener('click', function(e) {
        if (e.target === editModal) {
            closeEditModalHandler();
        }
    });
    
    // Handle window close to stop typing
    window.addEventListener('beforeunload', function() {
        if (isTyping) {
            sendTypingStatus(false);
        }
    });
});

// WebSocket connection
function connectWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws?username=${encodeURIComponent(currentUsername)}`;
    
    console.log('🔌 Connecting to WebSocket:', wsUrl);
    showConnectionStatus('connecting', 'Connecting...');
    
    ws = new WebSocket(wsUrl);
    
    ws.onopen = function(event) {
        console.log('✅ Connected to chat server', event);
        showConnectionStatus('connected', 'Connected');
        reconnectAttempts = 0;
        
        // Hide connection status after 2 seconds
        setTimeout(() => {
            hideConnectionStatus();
        }, 2000);
    };
    
    ws.onmessage = function(event) {
        console.log('📨 Received raw message:', event.data);
        console.log('🔔 WEBSOCKET MESSAGE RECEIVED - This should show if server sends anything!');
        try {
            const data = JSON.parse(event.data);
            console.log('📨 Parsed message:', data);
            handleMessage(data);
        } catch (error) {
            console.error('❌ Error parsing message:', error, 'Raw data:', event.data);
        }
    };
    
    ws.onclose = function(event) {
        console.log('❌ Disconnected from chat server. Code:', event.code, 'Reason:', event.reason, 'Event:', event);
        showConnectionStatus('disconnected', 'Disconnected');
        
        // Attempt to reconnect
        if (reconnectAttempts < maxReconnectAttempts) {
            reconnectAttempts++;
            console.log(`🔄 Attempting to reconnect... (${reconnectAttempts}/${maxReconnectAttempts})`);
            
            setTimeout(() => {
                connectWebSocket();
            }, 2000 * reconnectAttempts);
        } else {
            showConnectionStatus('disconnected', 'Connection failed. Please refresh the page.');
        }
    };
    
    ws.onerror = function(error) {
        console.error('❌ WebSocket error:', error);
        showConnectionStatus('disconnected', 'Connection error');
    };
}

// Handle incoming messages
function handleMessage(data) {
    console.log('📥 Handling message type:', data.type, 'Full data:', data);
    
    // Debug: Check if required DOM elements exist
    if (data.type === 'userList') {
        console.log('🔍 Debug - userCountSpan exists:', !!userCountSpan);
        console.log('🔍 Debug - onlineCountSpan exists:', !!onlineCountSpan);
        console.log('🔍 Debug - usersList exists:', !!usersList);
    }
    
    if (data.type === 'message') {
        console.log('🔍 Debug - messagesContainer exists:', !!messagesContainer);
    }
    
    switch (data.type) {
        case 'message':
            console.log('💬 Processing message:', data);
            addMessage(data);
            break;
        case 'userList':
            console.log('👥 Processing user list:', data.users, 'Count:', data.count);
            updateUsersList(data.users, data.count);
            updateTypingIndicator(data.users);
            break;
        case 'messageEdited':
            console.log('✏️ Processing message edit:', data);
            updateMessage(data.messageId, data.content);
            break;
        case 'messageDeleted':
            console.log('🗑️ Processing message delete:', data);
            removeMessage(data.messageId);
            break;
        default:
            console.log('❓ Unknown message type:', data.type, 'Data:', data);
    }
}

// Send message
function sendMessage() {
    const message = messageInput.value.trim();
    if (!message || !ws || ws.readyState !== WebSocket.OPEN) {
        console.log('❌ Cannot send message. Message:', message, 'WebSocket state:', ws ? ws.readyState : 'null');
        return;
    }
    
    console.log('📤 Sending message:', message);
    
    // Stop typing indicator
    if (isTyping) {
        isTyping = false;
        sendTypingStatus(false);
    }
    
    const messageData = {
        type: 'message',
        content: message
    };
    
    ws.send(JSON.stringify(messageData));
    messageInput.value = '';
    sendButton.disabled = true;
    
    // Clear typing timeout
    clearTimeout(typingTimeout);
}

// Send typing status
function sendTypingStatus(typing) {
    if (ws && ws.readyState === WebSocket.OPEN) {
        console.log('⌨️ Sending typing status:', typing);
        const typingData = {
            type: 'typing',
            isTyping: typing
        };
        ws.send(JSON.stringify(typingData));
    }
}

// Add message to chat
function addMessage(data) {
    console.log('💬 Adding message to chat:', data);
    
    // Debug: Check if messagesContainer exists
    if (!messagesContainer) {
        console.error('❌ messagesContainer not found!');
        return;
    }
    
    console.log('✅ messagesContainer found, current children count:', messagesContainer.children.length);
    
    // Remove welcome message if it exists
    const welcomeMessage = messagesContainer.querySelector('.welcome-message');
    if (welcomeMessage) {
        console.log('🗑️ Removing welcome message');
        welcomeMessage.remove();
    }
    
    const messageElement = document.createElement('div');
    messageElement.className = 'message';
    messageElement.dataset.messageId = data.id;
    
    const isOwnMessage = data.username === currentUsername;
    if (isOwnMessage) {
        messageElement.classList.add('own');
        currentUserId = data.userId; // Store current user ID
    }
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = data.username.charAt(0).toUpperCase();
    
    const content = document.createElement('div');
    content.className = 'message-content';
    
    const header = document.createElement('div');
    header.className = 'message-header';
    
    const username = document.createElement('span');
    username.className = 'message-username';
    username.textContent = data.username;
    
    const time = document.createElement('span');
    time.className = 'message-time';
    time.textContent = formatTime(new Date(data.timestamp));
    
    header.appendChild(username);
    header.appendChild(time);
    
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.textContent = data.content;
    
    content.appendChild(header);
    content.appendChild(bubble);
    
    // Add action buttons for own messages
    if (isOwnMessage) {
        const actions = document.createElement('div');
        actions.className = 'message-actions';
        
        const editBtn = document.createElement('button');
        editBtn.className = 'action-btn edit';
        editBtn.innerHTML = '<i class="fas fa-edit"></i>';
        editBtn.title = 'Edit message';
        editBtn.onclick = () => editMessage(data.id, data.content);
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'action-btn delete';
        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
        deleteBtn.title = 'Delete message';
        deleteBtn.onclick = () => deleteMessage(data.id);
        
        actions.appendChild(editBtn);
        actions.appendChild(deleteBtn);
        content.appendChild(actions);
    }
    
    messageElement.appendChild(avatar);
    messageElement.appendChild(content);
    
    messagesContainer.appendChild(messageElement);
    console.log('✅ Message element added to DOM, new children count:', messagesContainer.children.length);
    
    scrollToBottom();
}

// Update message content (for edits)
function updateMessage(messageId, newContent) {
    console.log('✏️ Updating message:', messageId, newContent);
    const messageElement = messagesContainer.querySelector(`[data-message-id="${messageId}"]`);
    if (messageElement) {
        const bubble = messageElement.querySelector('.message-bubble');
        bubble.textContent = newContent;
        
        // Add edited indicator
        const header = messageElement.querySelector('.message-header');
        let editedIndicator = header.querySelector('.message-edited');
        if (!editedIndicator) {
            editedIndicator = document.createElement('span');
            editedIndicator.className = 'message-edited';
            editedIndicator.textContent = '(edited)';
            header.appendChild(editedIndicator);
        }
    }
}

// Remove message (for deletions)
function removeMessage(messageId) {
    console.log('🗑️ Removing message:', messageId);
    const messageElement = messagesContainer.querySelector(`[data-message-id="${messageId}"]`);
    if (messageElement) {
        messageElement.style.animation = 'messageSlideOut 0.3s ease-in forwards';
        setTimeout(() => {
            messageElement.remove();
        }, 300);
    }
}

// Edit message
function editMessage(messageId, currentContent) {
    console.log('✏️ Editing message:', messageId);
    editingMessageId = messageId;
    editTextarea.value = currentContent;
    editModal.style.display = 'flex';
    editTextarea.focus();
}

// Save edited message
function saveEditedMessage() {
    const newContent = editTextarea.value.trim();
    if (!newContent || !editingMessageId) return;
    
    console.log('💾 Saving edited message:', editingMessageId, newContent);
    
    const editData = {
        type: 'edit',
        messageId: editingMessageId,
        content: newContent
    };
    
    ws.send(JSON.stringify(editData));
    closeEditModalHandler();
}

// Delete message
function deleteMessage(messageId) {
    if (confirm('Are you sure you want to delete this message?')) {
        console.log('🗑️ Deleting message:', messageId);
        const deleteData = {
            type: 'delete',
            messageId: messageId
        };
        
        ws.send(JSON.stringify(deleteData));
    }
}

// Close edit modal
function closeEditModalHandler() {
    editModal.style.display = 'none';
    editingMessageId = null;
    editTextarea.value = '';
}

// Update users list
function updateUsersList(users, count) {
    console.log('👥 Updating users list. Input users:', users, 'Input count:', count);
    
    if (!users) {
        console.error('❌ No users data provided');
        return;
    }
    
    if (!Array.isArray(users)) {
        console.error('❌ Users is not an array:', users);
        return;
    }
    
    const actualCount = count || users.length;
    console.log('👥 Setting count to:', actualCount);
    
    // Debug: Check elements before updating
    console.log('🔍 Before update - userCountSpan:', userCountSpan, 'current text:', userCountSpan?.textContent);
    console.log('🔍 Before update - onlineCountSpan:', onlineCountSpan, 'current text:', onlineCountSpan?.textContent);
    
    // Update count displays
    if (userCountSpan) {
        userCountSpan.textContent = actualCount.toString();
        console.log('✅ Updated userCountSpan to:', userCountSpan.textContent);
    } else {
        console.error('❌ userCountSpan not found!');
    }
    
    if (onlineCountSpan) {
        onlineCountSpan.textContent = `${actualCount} online`;
        console.log('✅ Updated onlineCountSpan to:', onlineCountSpan.textContent);
    } else {
        console.error('❌ onlineCountSpan not found!');
    }
    
    console.log('👥 Updated count displays - userCount:', userCountSpan?.textContent, 'onlineCount:', onlineCountSpan?.textContent);
    
    // Clear and rebuild users list
    if (usersList) {
        usersList.innerHTML = '';
        console.log('👥 Cleared users list, rebuilding with', users.length, 'users');
        
        users.forEach((user, index) => {
            console.log(`👤 Adding user ${index + 1}:`, user);
            
            const userElement = document.createElement('div');
            userElement.className = 'user-item';
            
            const avatar = document.createElement('div');
            avatar.className = 'user-avatar';
            avatar.textContent = user.username ? user.username.charAt(0).toUpperCase() : '?';
            
            const name = document.createElement('div');
            name.className = 'user-name';
            name.textContent = user.username || 'Unknown';
            
            userElement.appendChild(avatar);
            userElement.appendChild(name);
            
            if (user.isTyping) {
                const typing = document.createElement('div');
                typing.className = 'user-typing';
                typing.textContent = 'typing...';
                userElement.appendChild(typing);
                console.log(`⌨️ User ${user.username} is typing`);
            }
            
            usersList.appendChild(userElement);
            console.log(`✅ Added user ${user.username} to list`);
        });
        
        console.log('✅ Users list update complete. Total users displayed:', users.length);
    } else {
        console.error('❌ usersList not found!');
    }
}

// Update typing indicator
function updateTypingIndicator(users) {
    const typingUsers = users.filter(user => user.isTyping && user.username !== currentUsername);
    
    if (typingUsers.length > 0) {
        let typingMessage;
        if (typingUsers.length === 1) {
            typingMessage = `${typingUsers[0].username} is typing...`;
        } else if (typingUsers.length === 2) {
            typingMessage = `${typingUsers[0].username} and ${typingUsers[1].username} are typing...`;
        } else {
            typingMessage = `${typingUsers.length} people are typing...`;
        }
        
        typingText.textContent = typingMessage;
        typingIndicator.style.display = 'flex';
    } else {
        typingIndicator.style.display = 'none';
    }
}

// Show connection status
function showConnectionStatus(status, message) {
    console.log('📡 Connection status:', status, message);
    connectionStatus.className = `connection-status ${status} show`;
    connectionStatus.querySelector('span').textContent = message;
    
    // Update icon based on status
    const icon = connectionStatus.querySelector('i');
    switch (status) {
        case 'connecting':
            icon.className = 'fas fa-wifi';
            break;
        case 'connected':
            icon.className = 'fas fa-check-circle';
            break;
        case 'disconnected':
            icon.className = 'fas fa-exclamation-triangle';
            break;
    }
}

// Hide connection status
function hideConnectionStatus() {
    connectionStatus.classList.remove('show');
}

// Scroll to bottom of messages
function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Format time
function formatTime(date) {
    return date.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

// Add CSS animation for message removal
const style = document.createElement('style');
style.textContent = `
    @keyframes messageSlideOut {
        to {
            opacity: 0;
            transform: translateX(-100%);
            height: 0;
            margin: 0;
            padding: 0;
        }
    }
`;
document.head.appendChild(style);

// Theme Management Functions
function initializeTheme() {
    // Check for saved theme preference or default to dark mode
    const savedTheme = localStorage.getItem('telechat-theme') || 'dark';
    setTheme(savedTheme);
    
    // Add event listener to theme toggle button
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
}

function setTheme(theme) {
    const body = document.body;
    const themeIcon = themeToggle?.querySelector('i');
    
    if (theme === 'light') {
        body.classList.add('light-mode');
        if (themeIcon) {
            themeIcon.className = 'fas fa-sun';
        }
    } else {
        body.classList.remove('light-mode');
        if (themeIcon) {
            themeIcon.className = 'fas fa-moon';
        }
    }
    
    // Save theme preference
    localStorage.setItem('telechat-theme', theme);
    console.log('🎨 Theme set to:', theme);
}

function toggleTheme() {
    const isLightMode = document.body.classList.contains('light-mode');
    const newTheme = isLightMode ? 'dark' : 'light';
    setTheme(newTheme);
} 